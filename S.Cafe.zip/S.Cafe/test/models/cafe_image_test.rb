require 'test_helper'

class CafeImageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
