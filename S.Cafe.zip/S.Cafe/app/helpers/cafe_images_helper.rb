module CafeImagesHelper
end
