class CafeCommentsController < ApplicationController
  def create
    cafe_image = CafeImage.find(params[:cafe_image_id])
    comment = current_user.cafe_comments.new(cafe_comment_params)
    comment.cafe_image_id = cafe_image.id
    comment.save
    redirect_to cafe_image_path(cafe_image)
  end

  def destroy
    CafeComment.find_by(id: params[:id]).destroy
    redirect_to cafe_image_path(params[:cafe_image_id])
  end
  
   private

  def cafe_comment_params
    params.require(:cafe_comment).permit(:comment)
  end
  
end
