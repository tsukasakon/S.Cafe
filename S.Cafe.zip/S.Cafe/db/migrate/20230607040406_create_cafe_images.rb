class CreateCafeImages < ActiveRecord::Migration[5.2]
  def change
    create_table :cafe_images do |t|
      
      t.string :image_id
      t.text :school_name
      t.text :caption
      t.integer :user_id

      t.timestamps
    end
  end
end
