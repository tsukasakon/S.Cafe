Rails.application.routes.draw do
  devise_for :users
 root to: 'homes#top'
  
  resources :cafe_images, only: [:new, :create, :index, :show, :destroy]
  
  resources :cafe_images, only: [:new, :create, :index, :show, :destroy] do
  resource :favorites, only: [:create, :destroy]
  resources :cafe_comments, only: [:create, :destroy]
  end
  
 resources :users, only: [:show, :edit, :update]
 
 
  
end
