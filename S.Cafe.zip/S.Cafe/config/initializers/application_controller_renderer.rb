# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end


Refile.secret_key = 'fa87b82150a1cccb104a8d7e786a07ffada8e5345614e71161c171bbbaec6f75061b9277c73549627e5c347729108606e8a1fc2c3dc4deba2ec8c47520748697'